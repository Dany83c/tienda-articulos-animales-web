// Asegurar que el LocalStorage tenga el carrito inicializado
if (!localStorage.getItem("productosCarrito")) {
    localStorage.setItem("productosCarrito", JSON.stringify([]))
}

function actualizarCarritoHTML() {
    const carrito = JSON.parse(localStorage.getItem("productosCarrito")) || []
    const contenedor = document.getElementById("carrito")

    if (!contenedor) return

    if (carrito.length === 0) {
        contenedor.innerHTML = "<p class='text-break'>El carrito está vacío :(</p>"
        return
    }

    let total = 0 
    let html = "<ul class='list-group'>"

    carrito.forEach(item => {
        total += item.precio * item.cantidad // Calcular total 
        html += `
            <li class="list-group-item d-flex justify-content-between align-items-center">
                ${item.nombre} x${item.cantidad} - $${item.precio * item.cantidad}
                <button class="btn btn-sm btn-danger btn-eliminar" data-id="${item.id}">&times</button>
            </li>`
    })

    html += `</ul><p class="mt-2 fw-bold">Total: $${total}</p>` 
    contenedor.innerHTML = html

    const btnEliminar = document.querySelectorAll(".btn-eliminar")
    btnEliminar.forEach(btn => {
        btn.addEventListener("click", () => {
            eliminarDelCarrito(btn.dataset.id)
        })
    })
}

function actualizarDropdownCarrito() {
    const carrito = JSON.parse(localStorage.getItem("productosCarrito")) || []
    const listaProductos = document.getElementById("lista-productos-dropdown")
    const totalElement = document.getElementById("total-carrito-dropdown")
    
    // Si no encontramos los elementos, salimos
    if (!listaProductos || !totalElement) return

    let html = ""
    let total = 0

    if (carrito.length === 0) {
        listaProductos.innerHTML = "<li>El carrito está vacío.</li>"
        totalElement.textContent = "$0"
        return
    }

    carrito.forEach(item => {
        total += item.precio * item.cantidad
        html += `<li>${item.nombre} x${item.cantidad} - $${item.precio * item.cantidad}</li>`
    })

    listaProductos.innerHTML = html
    totalElement.textContent = `$${total}`
}

// Función para agregar un producto al carrito
function agregarAlCarrito(id, cantidad = 1) {
    let carrito = JSON.parse(localStorage.getItem("productosCarrito")) || []
    const producto = productos.find(p => p.id == id)

    if (!producto) return

    const index = carrito.findIndex(p => p.id == id)

    if (index >= 0) {
        carrito[index].cantidad += cantidad
    } else {
        carrito.push({ ...producto, cantidad })
    }

    localStorage.setItem("productosCarrito", JSON.stringify(carrito))
    actualizarCarritoHTML() // Actualizar la vista del carrito
    actualizarDropdownCarrito()
}

// Función para eliminar un producto del carrito
function eliminarDelCarrito(id) {
    let carrito = JSON.parse(localStorage.getItem("productosCarrito")) || []
    carrito = carrito.filter(p => p.id != id)
    localStorage.setItem("productosCarrito", JSON.stringify(carrito))
    actualizarCarritoHTML()
    actualizarDropdownCarrito()
}

// Asegura de que el carrito se actualice cuando la página carga
document.addEventListener("DOMContentLoaded", () => {
    actualizarCarritoHTML()
    actualizarDropdownCarrito()
})




/*

//guardar los productos del carrito en el localstorage
if (!localStorage.getItem("productosCarrito")) {
    localStorage.setItem("productosCarrito", JSON.stringify([]))
}

//LocalStorage usuarios para guardar usarios registrados si no existe uno ya
if (!localStorage.getItem("usuarios")) {
    localStorage.setItem("usuarios", JSON.stringify([]))
}
//actualiza el estado del carrito en el html
function actualizarCarritoHTML() {
    const carrito = JSON.parse(localStorage.getItem("productosCarrito")) || []
    const contenedor = document.getElementById("carrito")
    
    if (!contenedor) return

    if (carrito.length === 0) {
        contenedor.innerHTML = "<p style='font-size: 100px'> El carrito está vacío :( </p>"
        return
    }

    let html = "<ul class='list-group'>"
    let total = 0

    carrito.forEach(item => {
        total += item.precio * item.cantidad
        html += `
            <li class="list-group-item d-flex justify-content-between align-items-center">
                ${item.nombre} x${item.cantidad} - $${item.precio * item.cantidad}
                <button class="btn btn-sm btn-danger btn-eliminar" data-id="${item.id}">&times</button>
            </li>`})

    html += `</ul><p class="mt-2 fw-bold">Total: $${total}</p>`
    contenedor.innerHTML = html
    // listener de botones de eliminar
    const btnEliminar = document.querySelectorAll(".btn-eliminar")
    btnEliminar.forEach(btn => {
        btn.addEventListener("click", () => {
            eliminarDelCarrito(btn.dataset.id)
        })
    })
}

// agregar al carrito
function agregarAlCarrito(id, cantidad = 1) {
    let carrito = JSON.parse(localStorage.getItem("productosCarrito")) || []
    const producto = productos.find(p => p.id == id)
    
    if (!producto) return

    //  si el producto ya existe en el carrito
    const index = carrito.findIndex(p => p.id == id)
    if (index >= 0) {
        // Si existe suma la cantidad
        carrito[index].cantidad += cantidad
    } else {
        // Si no existe, agregar uno nuevo
        carrito.push({ ...producto, cantidad })
    }

    localStorage.setItem("productosCarrito", JSON.stringify(carrito))
    actualizarCarritoHTML()
}
// listener de botones agregar al carrito
const btnAgregar = document.querySelectorAll(".btn-agregar-carrito")
// Usa un bucle forEach para agregar el listener a cada botón individualmente
btnAgregar.forEach(btn => {
    btn.addEventListener("click", () => {
        const productId = btn.dataset.id
        // La variable `btn` ahora está definida dentro del bucle
        // `document.getElementById("cantidad")` solo funciona si tienes un solo input para cantidad
        // Si no, puedes omitirlo o pasar un valor predeterminado
        const cantidad = parseInt(document.getElementById("cantidad").value) || 1  // Un valor fijo si no hay un input de cantidad por producto
        agregarAlCarrito(productId, cantidad)
    })
})






if (btnAgregar) {
    btnAgregar.addEventListener("click", () => {
        const productId = btn.dataset.id
        const cantidad = parseInt(document.getElementById("cantidad").value) || 1
        agregarAlCarrito(productId, cantidad)
    })
}
    





// Función para eliminar un producto del carrito
function eliminarDelCarrito(id) {
    let carrito = JSON.parse(localStorage.getItem("productosCarrito")) || []
    carrito = carrito.filter(p => p.id != id)
    localStorage.setItem("productosCarrito", JSON.stringify(carrito))
    actualizarCarritoHTML()
}

//cuando carga la pagina actualiza tambien el carrito
document.addEventListener("DOMContentLoaded", () => {
    actualizarCarritoHTML()
})


*/
