const productos = [
        {
            "id": 1,
            "nombre": "Galleta perro",
            "descripcion": "Galletas caseras para perro hechas con ingredientes de grado humano",
            "precio": 2990,
            "imagen": "https://dojiw2m9tvv09.cloudfront.net/42482/product/X_galletajpg1468.jpg?129&time=1757135042"
        },
        {
            "id": 2,
            "nombre": "Collar perro",
            "descripcion": "Collar tactico para perro mediano y grande",
            "precio": 4600,
            "imagen": "https://i5.walmartimages.cl/asr/8282f4e5-1417-4e34-b973-a3b24db75979.fa98e0af34ca671459d93bea6041c350.png?odnHeight=612&odnWidth=612&odnBg=FFFFFF"
        },
        {
            "id": 3,
            "nombre": "Pala para arenero",
            "descripcion": "Marca generica, ideal para areneros de gato",
            "precio": 1990,
            "imagen": "https://www.tusmascotas.cl/wp-content/uploads/2021/05/pala-azul-1.png.webp"
        },
        {
            "id": 4,
            "nombre": "Churu gato sabor atún",
            "descripcion": "sachet de 4 tubos sabor atún",
            "precio": 2300,
            "imagen": "https://petvet.cl/cdn/shop/files/churu-gato-tuna-537251_5000x.jpg?v=1714140535"
        },
        {
        "id": 5,
        "nombre": "Rueda metalica Erizo, Cuy, roedores",
        "descripcion": "rueda metalica 31 cm de alto x 28 cm de diámetro x 15 cm de ancho",
        "precio": 12000,
        "imagen": "https://http2.mlstatic.com/D_NQ_NP_844200-MLC45841137057_052021-O-rueda-erizo-30-cm-metalica-hamster-cuy-rata.webp"
    },
    {
        "id": 6,
        "nombre": "Arena sanitaria para gato 5kg",
        "descripcion": "Arena aglomerante para gatos, control de olores",
        "precio": 7000,
        "imagen": "https://http2.mlstatic.com/D_NQ_NP_802754-MLA83031164355_032025-O.webp"
    },
    
    {
        "id": 7,
        "nombre": "Snack perro pollo deshidratado 400g",
        "descripcion": "Tiras de pollo deshidratado, alto en proteína",
        "precio": 7300,
        "imagen": "https://http2.mlstatic.com/D_NQ_NP_2X_678970-MLU78483693441_082024-F.webp"
    },
    {
        "id": 8,
        "nombre": "Juguete gato ratón de peluche",
        "descripcion": "Ratón de peluche con catnip para gatos",
        "precio": 3500,
        "imagen": "https://http2.mlstatic.com/D_NQ_NP_648377-MLC54953388579_042023-O-juguete-rascador-gatos-raton-rayado-tamano-7-cm-hey.webp"
    },
    {
        "id": 9,
        "nombre": "Correa extensible para perro 5m",
        "descripcion": "Correa retráctil hasta 5 metros",
        "precio": 3300,
        "imagen": "https://http2.mlstatic.com/D_NQ_NP_876102-MLU79135171199_092024-O.webp"
    },
    {
        "id": 10,
        "nombre": "Cama para perro mediano",
        "descripcion": "Cama acolchada y cómoda para perros de tamaño mediano",
        "precio": 9300,
        "imagen": "https://http2.mlstatic.com/D_NQ_NP_827755-MLA79668916121_092024-O.webp"
    },
    {
        "id": 11,
        "nombre": "Cepillo para gato con autolimpieza",
        "descripcion": "Cepillo para retirar pelo muerto y masajear al gato",
        "precio": 2200,
        "imagen": "https://http2.mlstatic.com/D_NQ_NP_632040-MLA90644782077_082025-O.webp"
    },
    {
        "id": 12,
        "nombre": "Alimento perro Nomade Raza Med/gde 20kg",
        "descripcion": "Alimento Premium rico en proteína animal de alto valor biológico",
        "precio": 2200,
        "imagen": "https://http2.mlstatic.com/D_NQ_NP_2X_645952-MLU72604611387_102023-F.webp"
    }
                ]